﻿using Embus.Metodos;
using Project;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EMBus
{
    public partial class AdministrarBus : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //this.Visible = false;
            //this.divCorreo.Visible = false;
        }

        protected void btnagregarbus_Click(object sender, EventArgs e)
        {

            CatalogBus catbus = new CatalogBus();
            int marca = ddmarca.SelectedIndex;
            int id_oficina = int.Parse(ddidoficina.SelectedValue.ToString());
            int cap = Int32.Parse(capacidad.Text);

            Bus bus_temp = new Bus(patente.Text, marca, id_oficina, apodo.Text, cap, true);

            if (catbus.VerificarPatenteExistente(patente.Text) == 1)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Success", "<script type='text/javascript'>alert('Error, El bus ya se encuentra registrado');window.location='AdministrarBus.aspx';</script>'");
            }
            else
            {
                catbus.agregarBus(bus_temp);
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Success", "<script type='text/javascript'>alert('Bus agregado satisfactoriamente');window.location='AdministrarBus.aspx';</script>'");
            }

        }
    }
}