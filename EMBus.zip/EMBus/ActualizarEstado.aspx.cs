﻿using Embus.Metodos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EMBus
{
    public partial class ActualizarEstado : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            gridBuses.DataBind();
            datosBusesActivos.DataBind();
            gridConductores.DataBind();
            datosConductoresActivos.DataBind();
            gridAuxiliares.DataBind();
            datosauxiliaresactivos.DataBind();
        }

        protected void btncambiarestado_Click(object sender, EventArgs e)
        {
            CatalogBus catalog_bus = new CatalogBus();
            string patente = ddpatente.SelectedValue;
            bool estado;
            if (ddestado.SelectedValue == "0")
            {
                estado = false;
                catalog_bus.cambiarEstadoBus(patente, estado);
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Success", "<script type='text/javascript'>alert('Bus Dado de Baja correctamente');window.location='ActualizarEstado.aspx';</script>'");
            }
            else
            {
                if (ddestado.SelectedValue == "1")
                {
                    estado = true;
                    catalog_bus.cambiarEstadoBus(patente, estado);
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Success", "<script type='text/javascript'>alert('Bus Dado de Alta correctamente');window.location='ActualizarEstado.aspx';</script>'");
                }
            }
        }

        protected void btncambiarestadoconductor_Click(object sender, EventArgs e)
        {
            CatalogConductor catalog_con = new CatalogConductor();
            string rut = ddconductores.SelectedValue;
            bool estado;
            if (ddcambiarestadoconductor.SelectedValue == "0")
            {
                estado = false;
                catalog_con.cambiarEstadoConductor(rut, estado);
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Success", "<script type='text/javascript'>alert('Conductor Dado de Baja correctamente');window.location='ActualizarEstado.aspx';</script>'");
            }
            else
            {
                if (ddcambiarestadoconductor.SelectedValue == "1")
                {
                    estado = true;
                    catalog_con.cambiarEstadoConductor(rut, estado);
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Success", "<script type='text/javascript'>alert('Conductor Dado de Alta correctamente');window.location='ActualizarEstado.aspx';</script>'");
                }
            }
        }

        protected void btncambiarestadoauxilar_Click(object sender, EventArgs e)
        {
            CatalogAuxiliar catalogAuxiliar = new CatalogAuxiliar();
            string rut = ddauxiliar.SelectedValue;
            bool estado;
            if (ddcambiarestadoauxiliar.SelectedValue == "0")
            {
                estado = false;
                catalogAuxiliar.cambiarEstadoAuxiliar(rut, estado);
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Success", "<script type='text/javascript'>alert('Auxiliar Dado de Baja correctamente');window.location='ActualizarEstado.aspx';</script>'");
            }
            else
            {
                if (ddcambiarestadoauxiliar.SelectedValue == "1")
                {
                    estado = true;
                    catalogAuxiliar.cambiarEstadoAuxiliar(rut, estado);
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Success", "<script type='text/javascript'>alert('Auxiliar Conductor Dado de Alta correctamente');window.location='ActualizarEstado.aspx';</script>'");
                }
            }
        }

        
    }
}